import { View, Text, TouchableOpacity, StyleSheet, Alert, Share, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import * as Clipboard from 'expo-clipboard';

type SiteCodeManagementProps = {
  siteId: string;
  siteName: string;
  siteCode: string;
};

const QR_BASE = 'https://api.qrserver.com/v1/create-qr-code/';

export default function SiteCodeManagement({ siteName, siteCode }: SiteCodeManagementProps) {
  const qrUri = `${QR_BASE}?size=200x200&data=${encodeURIComponent(siteCode)}`;

  const copyCode = async () => {
    await Clipboard.setStringAsync(siteCode);
    Alert.alert('Copied', 'Site code copied. Share it with workers to join.');
  };

  const shareCode = async () => {
    try {
      await Share.share({
        message: `Join ${siteName}!\n\nSite code: ${siteCode}\n\nLabourers: scan the QR in the app or enter this code to join.`,
        title: `Site code: ${siteCode}`,
      });
    } catch (e: unknown) {
      if ((e as { message?: string })?.message !== 'User did not share') console.error(e);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Ionicons name="key" size={24} color="#8B5CF6" />
        <Text style={styles.headerTitle}>Site code</Text>
      </View>
      <LinearGradient colors={['#8B5CF6', '#7C3AED']} style={styles.codeCard}>
        <Text style={styles.codeLabel}>Labourers scan this QR to join</Text>
        <View style={styles.qrWrap}>
          <Image source={{ uri: qrUri }} style={styles.qrImage} />
        </View>
        <Text style={styles.codeText}>{siteCode}</Text>
        <View style={styles.codeActions}>
          <TouchableOpacity style={styles.codeActionButton} onPress={copyCode}>
            <Ionicons name="copy-outline" size={20} color="#fff" />
            <Text style={styles.codeActionText}>Copy</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.codeActionButton} onPress={shareCode}>
            <Ionicons name="share-outline" size={20} color="#fff" />
            <Text style={styles.codeActionText}>Share</Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>
      <Text style={styles.hint}>
        Show this QR to labourers. They scan it in the app to join. Your friend is adding the scanner on the labourer dashboard.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#111',
  },
  codeCard: {
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    marginBottom: 12,
  },
  codeLabel: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.9)',
    marginBottom: 12,
  },
  qrWrap: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 12,
    marginBottom: 16,
  },
  qrImage: {
    width: 200,
    height: 200,
  },
  codeText: {
    fontSize: 22,
    fontWeight: '700',
    color: '#fff',
    letterSpacing: 2,
    marginBottom: 20,
  },
  codeActions: {
    flexDirection: 'row',
    gap: 12,
  },
  codeActionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  codeActionText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#fff',
  },
  hint: {
    fontSize: 13,
    color: '#6B7280',
    lineHeight: 18,
  },
});
