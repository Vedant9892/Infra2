// Base file that re-exports the native implementation
// Platform-specific files: SiteBoundary.native.tsx and SiteBoundary.web.tsx
export { default } from './SiteBoundary.native';
