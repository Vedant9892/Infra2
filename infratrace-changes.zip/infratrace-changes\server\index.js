const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
require('dotenv').config();

const PORT = process.env.PORT || 4000;
const mongoUri = process.env.MONGODB_URI;
if (!mongoUri) throw new Error('Missing MONGODB_URI in environment');

const app = express();

// CORS: allow Expo app (different origin) to call API
app.use((_req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-User-Id');
  if (_req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

let db;
async function connectDb() {
  const client = new MongoClient(mongoUri, {
    serverSelectionTimeoutMS: 5000,
    socketTimeoutMS: 45000,
  });
  try {
    await client.connect();
    db = client.db('infratrace');
    await db.collection('users').createIndex({ phoneNumber: 1 }, { unique: true });
    await db.collection('sites').createIndex({ code: 1 }, { unique: true });
    await db.collection('siteMemberships').createIndex({ userId: 1 }, { unique: true });
    await db.collection('tasks').createIndex({ siteId: 1 });
    await db.collection('material_requests').createIndex({ siteId: 1 });
    await db.collection('chatMessages').createIndex({ senderId: 1, receiverId: 1, createdAt: -1 });
    console.log('Connected to MongoDB');
  } catch (err) {
    console.error('MongoDB connection error:', err.message);
    throw err;
  }
}
const usersCollection = () => {
  if (!db) throw new Error('DB not initialized');
  return db.collection('users');
};
const sitesCollection = () => {
  if (!db) throw new Error('DB not initialized');
  return db.collection('sites');
};
const membershipsCollection = () => {
  if (!db) throw new Error('DB not initialized');
  return db.collection('siteMemberships');
};
const tasksCollection = () => {
  if (!db) throw new Error('DB not initialized');
  return db.collection('tasks');
};
const materialsCollection = () => {
  if (!db) throw new Error('DB not initialized');
  return db.collection('material_requests');
};
const attendanceCollection = () => {
  if (!db) throw new Error('DB not initialized');
  return db.collection('attendance');
};
const chatCollection = () => {
  if (!db) throw new Error('DB not initialized');
  return db.collection('chatMessages');
};

// small helper to add "id" alias for frontend expecting numeric id
const withId = (doc = {}) => ({ ...doc, id: doc._id ? doc._id.toString() : undefined, _id: doc._id ? doc._id.toString() : undefined });

// Sign Up - Create new account
app.post('/api/auth/register', async (req, res) => {
  try {
    const { phoneNumber, role } = req.body || {};
    if (!phoneNumber || !role) {
      return res.status(400).json({ success: false, message: 'phoneNumber and role are required' });
    }
    const users = usersCollection();

    // Check if user already exists
    const existingUser = await users.findOne({ phoneNumber });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'Account already exists with this phone number. Please sign in instead.'
      });
    }

    // Create new user
    const newUser = {
      phoneNumber,
      role,
      profileCompleted: false,
      createdAt: new Date()
    };
    const inserted = await users.insertOne(newUser);

    return res.json({
      success: true,
      userId: inserted.insertedId.toString(),
      profileCompleted: false
    });
  } catch (err) {
    console.error('Register error', err);
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// Sign In - Authenticate existing account
app.post('/api/auth/signin', async (req, res) => {
  try {
    const { phoneNumber, role } = req.body || {};
    if (!phoneNumber || !role) {
      return res.status(400).json({ success: false, message: 'phoneNumber and role are required' });
    }

    const users = usersCollection();
    const user = await users.findOne({ phoneNumber });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Account not found. Please sign up first.'
      });
    }

    // Verify role matches
    if (user.role !== role) {
      return res.status(400).json({
        success: false,
        message: `This account is registered as ${user.role}, not ${role}`
      });
    }

    return res.json({
      success: true,
      userId: user._id.toString(),
      user: {
        _id: user._id.toString(),
        name: user.name,
        email: user.email,
        phoneNumber: user.phoneNumber,
        role: user.role,
        profilePhoto: user.profilePhoto,
        location: user.location,
        profileCompleted: user.profileCompleted
      },
      profileCompleted: !!user.profileCompleted
    });
  } catch (err) {
    console.error('Sign in error', err);
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// Current user (very light auth: picks first user if none provided)
app.get('/api/users/me', async (req, res) => {
  try {
    const users = usersCollection();
    const userId = req.query.userId || req.headers['x-user-id'];
    const user = userId ? await users.findOne({ _id: new ObjectId(String(userId)) }) : await users.findOne({});
    if (!user) return res.status(404).json({ message: 'User not found' });
    const stats = { attendanceRate: 95, hoursWorked: 120, tasksCompleted: 12 };
    return res.json({ ...withId(user), stats });
  } catch (err) {
    console.error('users/me error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// Legacy login endpoint (kept for backward compatibility)
app.post('/api/auth/login', async (req, res) => {
  try {
    const { phoneNumber, role } = req.body || {};
    if (!phoneNumber || !role) {
      return res.status(400).json({ success: false, message: 'phoneNumber and role are required' });
    }
    const users = usersCollection();
    let user = await users.findOne({ phoneNumber });
    if (!user) {
      const newUser = { phoneNumber, role, profileCompleted: false, createdAt: new Date() };
      const inserted = await users.insertOne(newUser);
      user = { ...newUser, _id: inserted.insertedId };
    }
    return res.json({ success: true, userId: user._id.toString(), profileCompleted: !!user.profileCompleted });
  } catch (err) {
    if (err.code === 11000 && err.keyPattern?.phoneNumber) {
      const user = await usersCollection().findOne({ phoneNumber: req.body.phoneNumber });
      return res.json({ success: true, userId: user._id.toString(), profileCompleted: !!user.profileCompleted });
    }
    console.error('Login error', err);
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// Complete user profile (updated to include email and mobile)
app.post('/api/users/complete-profile', async (req, res) => {
  try {
    const { userId, name, email, phoneNumber, profilePhoto } = req.body || {};
    if (!userId || !name || !profilePhoto) {
      return res.status(400).json({ success: false, message: 'userId, name, and profilePhoto are required' });
    }

    const users = usersCollection();
    const updateData = {
      name,
      profilePhoto,
      profileCompleted: true
    };

    // Add email if provided
    if (email) {
      updateData.email = email;
    }

    // Add phoneNumber if provided (for verification)
    if (phoneNumber) {
      updateData.phoneNumber = phoneNumber;
    }

    const result = await users.findOneAndUpdate(
      { _id: new ObjectId(userId) },
      { $set: updateData },
      { returnDocument: 'after' }
    );
    const user = result?.value ?? result;
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    return res.json({ success: true, user: { ...user, _id: (user._id || user.id)?.toString?.() || user._id } });
  } catch (err) {
    console.error('Complete profile error', err);
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// Update user profile (for owner profile editing)
app.put('/api/users/update-profile', async (req, res) => {
  try {
    const { userId, name, profilePhoto } = req.body || {};
    if (!userId) {
      return res.status(400).json({ success: false, message: 'userId is required' });
    }

    const users = usersCollection();
    const updateData = {};

    if (name) updateData.name = name;
    if (profilePhoto) updateData.profilePhoto = profilePhoto;

    const result = await users.findOneAndUpdate(
      { _id: new ObjectId(userId) },
      { $set: updateData },
      { returnDocument: 'after' }
    );
    const user = result?.value ?? result;
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    return res.json({ success: true, user: { ...user, _id: (user._id || user.id)?.toString?.() || user._id } });
  } catch (err) {
    console.error('Update profile error', err);
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// Submit attendance (with address and proof photos)
app.post('/api/attendance/submit', async (req, res) => {
  try {
    const { userId, photoUri, proofPhotos, latitude, longitude, address } = req.body || {};

    if (!userId || !photoUri || !latitude || !longitude) {
      return res.status(400).json({
        success: false,
        message: 'userId, photoUri, latitude, and longitude are required'
      });
    }

    const attendanceRecord = {
      userId,
      photoUri,
      proofPhotos: proofPhotos || [],
      latitude,
      longitude,
      address: address || 'Address not available',
      timestamp: new Date(),
      status: 'present'
    };

  const attendance = attendanceCollection();
    const inserted = await attendance.insertOne(attendanceRecord);

    return res.json({
      success: true,
      attendanceId: inserted.insertedId.toString(),
      message: 'Attendance marked successfully'
    });
  } catch (err) {
    console.error('Submit attendance error', err);
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// Attendance: mark (mobile form)
app.post('/api/attendance', async (req, res) => {
  try {
    const { userId, status, location, photoUrl, siteId } = req.body || {};
    if (!userId || !status) return res.status(400).json({ message: 'userId and status are required' });
    const attendance = attendanceCollection();
    const doc = {
      userId,
      status,
      location: location || 'Job site',
      photoUrl: photoUrl || '',
      siteId: siteId ? String(siteId) : undefined,
      date: new Date(),
      timestamp: new Date(),
      isSynced: true,
    };
    const inserted = await attendance.insertOne(doc);
    return res.status(201).json({ ...doc, _id: inserted.insertedId.toString(), id: inserted.insertedId.toString() });
  } catch (err) {
    console.error('Attendance mark error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// Attendance history
app.get('/api/attendance', async (_req, res) => {
  try {
    const attendance = attendanceCollection();
    const list = await attendance.find({}).sort({ timestamp: -1 }).toArray();
    return res.json(list.map(withId));
  } catch (err) {
    console.error('Attendance history error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// List all sites (owner/supervisor dashboard)
app.get('/api/sites', async (req, res) => {
  try {
    const sites = sitesCollection();
    const memberships = membershipsCollection();
    const list = await sites.find({}).sort({ createdAt: -1 }).toArray();
    const out = await Promise.all(list.map(async (s) => {
      const count = await memberships.countDocuments({ siteId: s._id.toString() });
      return { ...withId(s), workersCount: count, status: s.status || 'active' };
    }));
    return res.json(out);
  } catch (err) {
    console.error('Sites list error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// Get workers (memberships + user info) for a site
app.get('/api/sites/:siteId/workers', async (req, res) => {
  try {
    const siteId = req.params.siteId;
    const memberships = membershipsCollection();
    const users = usersCollection();
    const mems = await memberships.find({ siteId }).sort({ createdAt: -1 }).toArray();
    const workers = await Promise.all(mems.map(async (m) => {
      let u = null;
      try {
        if (m.userId) u = await users.findOne({ _id: new ObjectId(String(m.userId)) });
      } catch (_) {}
      return {
        id: m._id.toString(),
        userId: String(m.userId),
        name: u?.name || `User ${m.userId}`,
        phone: u?.phoneNumber || '',
        role: m.role || 'member',
        status: m.status || 'pending',
        enrolledAt: m.createdAt,
        verified: m.status === 'approved',
      };
    }));
    return res.json({ workers });
  } catch (err) {
    console.error('Workers error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// Create site (owner generates code; manager code can be same for now)
app.post('/api/sites', async (req, res) => {
  try {
    const { name, location, code } = req.body || {};
    if (!name || !location) {
      return res.status(400).json({ success: false, message: 'name and location are required' });
    }
    const sites = sitesCollection();
    const siteCode = code || `SITE-${Math.random().toString(16).slice(2, 6).toUpperCase()}-${Math.floor(Math.random() * 900 + 100)}`;
    const doc = { name, location, code: siteCode, createdAt: new Date() };
    const inserted = await sites.insertOne(doc);
    return res.status(201).json({ ...doc, _id: inserted.insertedId.toString(), id: inserted.insertedId.toString() });
  } catch (err) {
    if (err.code === 11000) {
      return res.status(400).json({ success: false, message: 'Duplicate site code' });
    }
    console.error('Create site error', err);
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// Current site for a user (first approved membership)
app.get('/api/sites/current', async (req, res) => {
  try {
    const userId = req.query.userId || req.headers['x-user-id'];
    const memberships = membershipsCollection();
    const sites = sitesCollection();
    const membership = userId
      ? await memberships.findOne({ userId: String(userId), status: 'approved' })
      : await memberships.findOne({ status: 'approved' });
    if (!membership) return res.status(404).json({ message: 'No site membership found' });
    const site = await sites.findOne({ _id: new ObjectId(membership.siteId) });
    if (!site) return res.status(404).json({ message: 'Site not found' });
    return res.json({ ...withId(site), membership: withId(membership) });
  } catch (err) {
    console.error('Current site error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// Get site snapshot by code
app.get('/api/sites/by-code/:code', async (req, res) => {
  try {
    const { code } = req.params;
    const sites = sitesCollection();
    const memberships = membershipsCollection();
    const tasks = tasksCollection();
    const materials = materialsCollection();
    const site = await sites.findOne({ code });
    if (!site) return res.status(404).json({ message: 'Site not found for code' });
    const mems = await memberships.find({ siteId: site._id.toString() }).sort({ createdAt: -1 }).toArray();
    const taskList = await tasks.find({ siteId: site._id.toString() }).sort({ createdAt: -1 }).toArray();
    const mats = await materials.find({ siteId: site._id.toString() }).sort({ createdAt: -1 }).toArray();
    return res.json({
      site: withId(site),
      tasks: taskList.map(withId),
      materialRequests: mats.map(withId),
      memberships: mems.map(withId),
    });
  } catch (err) {
    console.error('By-code error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// Get site by id (for id-only navigation)
app.get('/api/sites/id/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const sites = sitesCollection();
    let site;
    try {
      site = await sites.findOne({ _id: new ObjectId(id) });
    } catch (_) {
      return res.status(404).json({ message: 'Site not found' });
    }
    if (!site) return res.status(404).json({ message: 'Site not found' });
    return res.json(withId(site));
  } catch (err) {
    console.error('Site by id error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// Enroll to site with hierarchy approvals
app.post('/api/sites/enroll', async (req, res) => {
  try {
    const { userId, role, code } = req.body || {};
    if (!userId || !role || !code) {
      return res.status(400).json({ message: 'userId, role, code are required' });
    }
    const sites = sitesCollection();
    const memberships = membershipsCollection();
    const site = await sites.findOne({ code });
    if (!site) return res.status(400).json({ message: 'Invalid site code' });

    const existing = await memberships.findOne({ userId });
    if (existing) return res.status(400).json({ message: 'User already enrolled to a site' });

    const status = role.toLowerCase() === 'owner' ? 'approved' : 'pending';
    const doc = {
      userId,
      role,
      siteId: site._id.toString(),
      status,
      createdAt: new Date(),
    };
    const inserted = await memberships.insertOne(doc);
    return res.json({ ...doc, _id: inserted.insertedId.toString(), id: inserted.insertedId.toString(), site: withId(site), requiresApproval: status !== 'approved' });
  } catch (err) {
    console.error('Enroll error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// Approve membership
app.patch('/api/sites/memberships/:id/approve', async (req, res) => {
  try {
    const membershipId = req.params.id;
    const { approverId, approverRole } = req.body || {};
    if (!approverId || !approverRole) {
      return res.status(400).json({ message: 'approverId and approverRole are required' });
    }
    const memberships = membershipsCollection();
    const membership = await memberships.findOne({ _id: new ObjectId(membershipId) });
    if (!membership) return res.status(404).json({ message: 'Membership not found' });
    if (membership.status === 'approved') return res.json(withId(membership));

    const targetRole = (membership.role || '').toLowerCase();
    const approverRoleLower = (approverRole || '').toLowerCase();
    if ((targetRole === 'supervisor' || targetRole === 'manager') && approverRoleLower !== 'owner') {
      return res.status(400).json({ message: 'Owner approval required' });
    }
    if ((targetRole === 'labour' || targetRole === 'labor' || targetRole === 'worker') && !['manager', 'supervisor', 'owner'].includes(approverRoleLower)) {
      return res.status(400).json({ message: 'Manager/supervisor/owner approval required' });
    }

    await memberships.updateOne(
      { _id: new ObjectId(membershipId) },
      { $set: { status: 'approved', approverId } }
    );
    const updated = await memberships.findOne({ _id: new ObjectId(membershipId) });
    return res.json(withId(updated));
  } catch (err) {
    console.error('Approve error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// Reject membership
app.patch('/api/sites/memberships/:id/reject', async (req, res) => {
  try {
    const membershipId = req.params.id;
    const { reason } = req.body || {};
    const memberships = membershipsCollection();
    const membership = await memberships.findOne({ _id: new ObjectId(membershipId) });
    if (!membership) return res.status(404).json({ message: 'Membership not found' });
    await memberships.updateOne(
      { _id: new ObjectId(membershipId) },
      { $set: { status: 'rejected', rejectionReason: reason || '' } }
    );
    const updated = await memberships.findOne({ _id: new ObjectId(membershipId) });
    return res.json(withId(updated));
  } catch (err) {
    console.error('Reject error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// Tasks: list (optional siteId, ?lite=1 for minimal payload)
app.get('/api/tasks', async (req, res) => {
  try {
    const tasks = tasksCollection();
    const siteId = req.query.siteId;
    const lite = req.query.lite === '1';
    const filter = siteId ? { siteId: String(siteId) } : {};
    const list = await tasks.find(filter).sort({ createdAt: -1 }).toArray();
    const mapped = list.map(withId);
    if (lite) {
      const out = mapped.map((t) => ({
        id: t.id,
        title: t.title,
        status: t.status,
        time: t.time,
        location: t.location,
        supervisor: t.supervisor,
        supervisorAvatar: t.supervisorAvatar,
      }));
      return res.json(out);
    }
    return res.json(mapped);
  } catch (err) {
    console.error('Tasks list error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// Tasks: update status
app.patch('/api/tasks/:id/status', async (req, res) => {
  try {
    const id = req.params.id;
    const { status } = req.body || {};
    if (!status) return res.status(400).json({ message: 'status is required' });
    const tasks = tasksCollection();
    const _id = new ObjectId(id);
    await tasks.updateOne({ _id }, { $set: { status } });
    const updated = await tasks.findOne({ _id });
    if (!updated) return res.status(404).json({ message: 'Task not found' });
    return res.json(withId(updated));
  } catch (err) {
    console.error('Task status error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// Tasks: assign
app.patch('/api/tasks/:id/assign', async (req, res) => {
  try {
    const id = req.params.id;
    const { assignedTo, siteId } = req.body || {};
    if (!assignedTo) return res.status(400).json({ message: 'assignedTo is required' });
    const tasks = tasksCollection();
    const _id = new ObjectId(id);
    await tasks.updateOne({ _id }, { $set: { assignedTo, siteId } });
    const updated = await tasks.findOne({ _id });
    if (!updated) return res.status(404).json({ message: 'Task not found' });
    return res.json(withId(updated));
  } catch (err) {
    console.error('Task assign error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// Material requests: create
app.post('/api/material-requests', async (req, res) => {
  try {
    const { siteId, item, quantity, unit, neededBy, note } = req.body || {};
    if (!siteId || !item || !quantity || !unit) {
      return res.status(400).json({ message: 'siteId, item, quantity, unit are required' });
    }
    const materials = materialsCollection();
    const doc = {
      siteId,
      item,
      quantity,
      unit,
      neededBy: neededBy || '',
      note: note || '',
      status: 'requested',
      createdAt: new Date(),
    };
    const inserted = await materials.insertOne(doc);
    return res.status(201).json({ ...doc, _id: inserted.insertedId.toString(), id: inserted.insertedId.toString() });
  } catch (err) {
    console.error('Create material error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// Material requests: list (optional siteId, ?lite=1 for minimal payload)
app.get('/api/material-requests', async (req, res) => {
  try {
    const siteId = req.query.siteId;
    const lite = req.query.lite === '1';
    const materials = materialsCollection();
    const filter = siteId ? { siteId: String(siteId) } : {};
    const list = await materials.find(filter).sort({ createdAt: -1 }).toArray();
    const mapped = list.map(withId);
    if (lite) {
      const out = mapped.map((m) => ({ id: m.id, item: m.item, quantity: m.quantity, unit: m.unit, status: m.status }));
      return res.json(out);
    }
    return res.json(mapped);
  } catch (err) {
    console.error('List material error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// Material requests: update status
app.patch('/api/material-requests/:id/status', async (req, res) => {
  try {
    const id = req.params.id;
    const { status } = req.body || {};
    if (!status) return res.status(400).json({ message: 'status is required' });
    const materials = materialsCollection();
    const _id = new ObjectId(id);
    await materials.updateOne({ _id }, { $set: { status } });
    const updated = await materials.findOne({ _id });
    if (!updated) return res.status(404).json({ message: 'Material request not found' });
    return res.json(withId(updated));
  } catch (err) {
    console.error('Update material status error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// Visibility snapshot by siteId
app.get('/api/visibility/site/:siteId', async (req, res) => {
  try {
    const { siteId } = req.params;
    const sites = sitesCollection();
    const memberships = membershipsCollection();
    const tasks = tasksCollection();
    const materials = materialsCollection();
    const attendance = attendanceCollection();
    const site = await sites.findOne({ _id: new ObjectId(siteId) });
    if (!site) return res.status(404).json({ message: 'Site not found' });
    const siteIdStr = site._id.toString();
    const [taskList, mats, attendanceList, mems] = await Promise.all([
      tasks.find({ siteId: siteIdStr }).sort({ createdAt: -1 }).toArray(),
      materials.find({ siteId: siteIdStr }).sort({ createdAt: -1 }).toArray(),
      attendance.find({ siteId: siteIdStr }).sort({ timestamp: -1 }).toArray(),
      memberships.find({ siteId: siteIdStr }).toArray(),
    ]);
    return res.json({
      site: withId(site),
      tasks: taskList.map(withId),
      materialRequests: mats.map(withId),
      attendance: attendanceList.map(withId),
      memberships: mems.map(withId),
    });
  } catch (err) {
    console.error('Visibility snapshot error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// --- Chat (hierarchical, with photos) ---

function canChatWith(myRole, otherRole) {
  const r = (s) => (s || '').toLowerCase();
  const m = r(myRole);
  const o = r(otherRole);
  if (m === 'labour') return o === 'supervisor';
  if (m === 'supervisor') return o === 'labour' || o === 'engineer';
  if (m === 'engineer') return o === 'supervisor' || o === 'owner';
  if (m === 'owner') return o === 'engineer';
  return false;
}

async function getChatContacts(userId) {
  const users = usersCollection();
  const memberships = membershipsCollection();
  const me = await users.findOne({ _id: new ObjectId(String(userId)) });
  if (!me) return null;
  const myRole = me.role || 'labour';
  const contacts = [];
  const added = new Set();

  if (myRole === 'owner') {
    const mems = await memberships.find({}).toArray();
    const engineerUserIds = [...new Set(mems.filter((m) => (m.role || '').toLowerCase() === 'engineer').map((m) => String(m.userId)))];
    for (const uid of engineerUserIds) {
      if (uid === String(userId) || added.has(uid)) continue;
      const u = await users.findOne({ _id: new ObjectId(uid) });
      if (u && canChatWith(myRole, u.role)) {
        added.add(uid);
        contacts.push({ userId: uid, name: u.name || `User ${uid}`, role: u.role || 'engineer' });
      }
    }
  } else {
    const myMem = await memberships.findOne({ userId: String(userId), status: 'approved' });
    const siteId = myMem?.siteId;
    if (siteId) {
      const mems = await memberships.find({ siteId, status: 'approved' }).toArray();
      for (const m of mems) {
        const uid = String(m.userId);
        if (uid === String(userId) || added.has(uid)) continue;
        const u = await users.findOne({ _id: new ObjectId(uid) });
        if (!u) continue;
        const otherRole = m.role || u.role || 'member';
        if (canChatWith(myRole, otherRole)) {
          added.add(uid);
          contacts.push({ userId: uid, name: u.name || `User ${uid}`, role: otherRole });
        }
      }
    }
    if (myRole === 'engineer' && canChatWith(myRole, 'owner')) {
      const owners = await users.find({ role: 'owner' }).toArray();
      for (const u of owners) {
        const uid = u._id.toString();
        if (added.has(uid)) continue;
        added.add(uid);
        contacts.push({ userId: uid, name: u.name || `Owner ${uid}`, role: 'owner' });
      }
    }
  }
  return contacts;
}

// GET /api/chat/contacts?userId=...
app.get('/api/chat/contacts', async (req, res) => {
  try {
    const userId = req.query.userId || req.headers['x-user-id'];
    if (!userId) return res.status(400).json({ message: 'userId required' });
    const contacts = await getChatContacts(userId);
    if (contacts === null) return res.status(404).json({ message: 'User not found' });
    return res.json({ contacts });
  } catch (err) {
    console.error('Chat contacts error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// GET /api/chat/messages?userId=...&otherUserId=...
app.get('/api/chat/messages', async (req, res) => {
  try {
    const userId = req.query.userId || req.headers['x-user-id'];
    const otherUserId = req.query.otherUserId;
    if (!userId || !otherUserId) return res.status(400).json({ message: 'userId and otherUserId required' });

    const chat = chatCollection();
    const list = await chat
      .find({
        $or: [
          { senderId: String(userId), receiverId: String(otherUserId) },
          { senderId: String(otherUserId), receiverId: String(userId) },
        ],
      })
      .sort({ createdAt: 1 })
      .toArray();

    const messages = list.map((m) => ({
      id: m._id.toString(),
      senderId: m.senderId,
      receiverId: m.receiverId,
      text: m.text || null,
      photoUrl: m.photoUrl || null,
      createdAt: m.createdAt,
      read: !!m.read,
    }));
    return res.json({ messages });
  } catch (err) {
    console.error('Chat messages error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// POST /api/chat/messages — send message (text and/or photoUrl)
app.post('/api/chat/messages', async (req, res) => {
  try {
    const { senderId, receiverId, text, photoUrl } = req.body || {};
    if (!senderId || !receiverId) return res.status(400).json({ message: 'senderId and receiverId required' });
    if (!text && !photoUrl) return res.status(400).json({ message: 'text or photoUrl required' });

    const users = usersCollection();
    const sender = await users.findOne({ _id: new ObjectId(String(senderId)) });
    const receiver = await users.findOne({ _id: new ObjectId(String(receiverId)) });
    if (!sender || !receiver) return res.status(404).json({ message: 'User not found' });
    if (!canChatWith(sender.role, receiver.role)) return res.status(403).json({ message: 'Cannot chat with this user' });

    const chat = chatCollection();
    const doc = {
      senderId: String(senderId),
      receiverId: String(receiverId),
      text: text || null,
      photoUrl: photoUrl || null,
      createdAt: new Date(),
      read: false,
    };
    const inserted = await chat.insertOne(doc);
    const out = {
      id: inserted.insertedId.toString(),
      senderId: doc.senderId,
      receiverId: doc.receiverId,
      text: doc.text,
      photoUrl: doc.photoUrl,
      createdAt: doc.createdAt,
      read: doc.read,
    };
    return res.status(201).json(out);
  } catch (err) {
    console.error('Chat send error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// PATCH /api/chat/messages/:id/read — mark as read
app.patch('/api/chat/messages/:id/read', async (req, res) => {
  try {
    const id = req.params.id;
    const chat = chatCollection();
    await chat.updateOne({ _id: new ObjectId(id) }, { $set: { read: true } });
    const updated = await chat.findOne({ _id: new ObjectId(id) });
    if (!updated) return res.status(404).json({ message: 'Message not found' });
    return res.json({
      id: updated._id.toString(),
      read: true,
    });
  } catch (err) {
    console.error('Chat mark-read error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// GET /api/chat/conversations?userId=...
app.get('/api/chat/conversations', async (req, res) => {
  try {
    const userId = req.query.userId || req.headers['x-user-id'];
    if (!userId) return res.status(400).json({ message: 'userId required' });
    const contacts = await getChatContacts(userId);
    if (contacts === null) return res.status(404).json({ message: 'User not found' });
    const chat = chatCollection();
    const conversations = await Promise.all(
      contacts.map(async (c) => {
        const msgs = await chat
          .find({
            $or: [
              { senderId: String(userId), receiverId: c.userId },
              { senderId: c.userId, receiverId: String(userId) },
            ],
          })
          .sort({ createdAt: -1 })
          .limit(1)
          .toArray();
        const last = msgs[0];
        const unread = await chat.countDocuments({
          senderId: c.userId,
          receiverId: String(userId),
          read: { $ne: true },
        });
        return {
          id: `conv-${c.userId}`,
          participantId: c.userId,
          participantName: c.name,
          participantRole: c.role,
          lastMessage: last ? (last.photoUrl ? '[Photo]' : (last.text || '')) : '',
          lastMessageTime: last ? last.createdAt : new Date(0),
          unreadCount: unread,
        };
      })
    );
    return res.json({ conversations });
  } catch (err) {
    console.error('Chat conversations error', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

connectDb()
  .then(() => app.listen(PORT, () => console.log(`API listening on ${PORT}`)))
  .catch((err) => {
    console.error('MongoDB connection failed', err.message);
    console.error('Please verify MONGODB_URI in your .env file');
    process.exit(1);
  });
