import { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  RefreshControl,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useUser } from '../../contexts/UserContext';
import { API_BASE_URL } from '../../constants/api';

interface Project {
  id: string;
  name: string;
  location: string;
  code?: string;
  status: 'active' | 'completed' | 'on-hold';
  progress: number;
  tasks: number;
  completedTasks: number;
  team: number;
}

type Filter = 'all' | 'active' | 'completed' | 'on-hold';

export default function Projects() {
  const router = useRouter();
  const { user } = useUser();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [filter, setFilter] = useState<Filter>('all');

  const fetchProjects = useCallback(async () => {
    if (!user?.id) {
      setLoading(false);
      setProjects([]);
      return;
    }
    try {
      const isOwnerOrSupervisor = user.role === 'owner' || user.role === 'supervisor';

      if (isOwnerOrSupervisor) {
        const sitesRes = await fetch(`${API_BASE_URL}/api/sites`);
        if (!sitesRes.ok) throw new Error('Failed to load sites');
        const sites = await sitesRes.json();

        const list: Project[] = await Promise.all(
          sites.map(async (site: any) => {
            const tasksRes = await fetch(`${API_BASE_URL}/api/tasks?siteId=${encodeURIComponent(site.id)}`);
            const tasks = tasksRes.ok ? await tasksRes.json() : [];
            const total = Array.isArray(tasks) ? tasks.length : 0;
            const completed = Array.isArray(tasks)
              ? tasks.filter((t: any) => (t.status || '').toLowerCase() === 'completed').length
              : 0;
            const progress = total > 0 ? Math.round((completed / total) * 100) : 0;
            const status = (site.status || 'active').toLowerCase();
            const safeStatus: 'active' | 'completed' | 'on-hold' =
              status === 'completed' || status === 'on-hold' ? status : 'active';
            return {
              id: site.id,
              name: site.name || 'Unnamed',
              location: site.location || `Code: ${site.code || ''}`,
              code: site.code,
              status: safeStatus,
              progress,
              tasks: total,
              completedTasks: completed,
              team: site.workersCount ?? 0,
            };
          })
        );
        setProjects(list);
      } else {
        const currentRes = await fetch(
          `${API_BASE_URL}/api/sites/current?userId=${encodeURIComponent(user.id)}`
        );
        if (currentRes.status === 404) {
          setProjects([]);
          setLoading(false);
          setRefreshing(false);
          return;
        }
        if (!currentRes.ok) throw new Error('Failed to load project');
        const current = await currentRes.json();
        const site = current;
        const siteId = site.id || site._id;

        const [tasksRes, workersRes] = await Promise.all([
          fetch(`${API_BASE_URL}/api/tasks?siteId=${encodeURIComponent(siteId)}`),
          fetch(`${API_BASE_URL}/api/sites/${encodeURIComponent(siteId)}/workers`),
        ]);
        const tasks = tasksRes.ok ? await tasksRes.json() : [];
        const workers = workersRes.ok ? ((await workersRes.json()).workers || []) : [];
        const total = Array.isArray(tasks) ? tasks.length : 0;
        const completed = Array.isArray(tasks)
          ? tasks.filter((t: any) => (t.status || '').toLowerCase() === 'completed').length
          : 0;
        const progress = total > 0 ? Math.round((completed / total) * 100) : 0;
        const status = (site.status || 'active').toLowerCase();
        const safeStatus: 'active' | 'completed' | 'on-hold' =
          status === 'completed' || status === 'on-hold' ? status : 'active';

        setProjects([
          {
            id: siteId,
            name: site.name || 'Unnamed',
            location: site.location || `Code: ${site.code || ''}`,
            code: site.code,
            status: safeStatus,
            progress,
            tasks: total,
            completedTasks: completed,
            team: Array.isArray(workers) ? workers.length : 0,
          },
        ]);
      }
    } catch (e) {
      console.error(e);
      Alert.alert('Error', 'Could not load projects. Is the server running?');
      setProjects([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id, user?.role]);

  useEffect(() => {
    setLoading(true);
    fetchProjects();
  }, [fetchProjects]);

  const onRefresh = () => {
    setRefreshing(true);
    fetchProjects();
  };

  const filtered = projects.filter((p) => {
    if (filter === 'all') return true;
    return p.status === filter;
  });

  const handleProjectPress = (p: Project) => {
    if (p.code) {
      router.push({ pathname: '/(owner)/site-detail', params: { code: p.code, id: p.id } });
    } else {
      router.push({ pathname: '/(owner)/site-detail', params: { id: p.id } });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return '#10B981';
      case 'completed':
        return '#3B82F6';
      case 'on-hold':
        return '#F59E0B';
      default:
        return '#6B7280';
    }
  };

  const getStatusBg = (status: string) => {
    switch (status) {
      case 'active':
        return '#D1FAE5';
      case 'completed':
        return '#DBEAFE';
      case 'on-hold':
        return '#FEF3C7';
      default:
        return '#F3F4F6';
    }
  };

  const filters: { key: Filter; label: string }[] = [
    { key: 'all', label: 'All' },
    { key: 'active', label: 'Active' },
    { key: 'completed', label: 'Completed' },
    { key: 'on-hold', label: 'On Hold' },
  ];

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Projects</Text>
        <TouchableOpacity onPress={onRefresh} disabled={loading}>
          <Ionicons name="refresh" size={24} color={loading ? '#9CA3AF' : '#000'} />
        </TouchableOpacity>
      </View>

      <View style={styles.filterRow}>
        {filters.map((f) => (
          <TouchableOpacity
            key={f.key}
            style={[styles.filterChip, filter === f.key && styles.filterChipActive]}
            onPress={() => setFilter(f.key)}
          >
            <Text style={filter === f.key ? styles.filterTextActive : styles.filterText}>
              {f.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView
        style={styles.content}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {loading ? (
          <View style={styles.center}>
            <ActivityIndicator size="large" color="#8B5CF6" />
            <Text style={styles.loadingText}>Loading projects…</Text>
          </View>
        ) : !user?.id ? (
          <View style={styles.center}>
            <Ionicons name="person-outline" size={64} color="#D1D5DB" />
            <Text style={styles.emptyTitle}>Sign in</Text>
            <Text style={styles.emptyText}>Sign in to see your projects</Text>
          </View>
        ) : filtered.length === 0 ? (
          <View style={styles.center}>
            <Ionicons name="construct-outline" size={64} color="#D1D5DB" />
            <Text style={styles.emptyTitle}>
              {filter === 'all' ? 'No projects' : `No ${filter} projects`}
            </Text>
            <Text style={styles.emptyText}>
              {user.role === 'owner' || user.role === 'supervisor'
                ? 'Create a site from the Supervisor dashboard.'
                : 'Join a site to see your assigned project.'}
            </Text>
          </View>
        ) : (
          filtered.map((project) => (
            <TouchableOpacity
              key={project.id}
              style={styles.projectCard}
              onPress={() => handleProjectPress(project)}
              activeOpacity={0.7}
            >
              <View style={styles.projectHeader}>
                <View style={styles.projectIcon}>
                  <Ionicons name="construct" size={24} color="#8B5CF6" />
                </View>
                <View
                  style={[
                    styles.statusBadge,
                    { backgroundColor: getStatusBg(project.status) },
                  ]}
                >
                  <Text
                    style={[
                      styles.statusText,
                      { color: getStatusColor(project.status) },
                    ]}
                  >
                    {project.status.charAt(0).toUpperCase() +
                      project.status.slice(1).replace('-', ' ')}
                  </Text>
                </View>
              </View>

              <Text style={styles.projectName}>{project.name}</Text>
              <View style={styles.locationRow}>
                <Ionicons name="location" size={14} color="#9CA3AF" />
                <Text style={styles.locationText}>{project.location}</Text>
              </View>

              <View style={styles.progressSection}>
                <View style={styles.progressHeader}>
                  <Text style={styles.progressLabel}>Progress</Text>
                  <Text style={styles.progressValue}>{project.progress}%</Text>
                </View>
                <View style={styles.progressBar}>
                  <View
                    style={[
                      styles.progressFill,
                      {
                        width: `${project.progress}%`,
                        backgroundColor: getStatusColor(project.status),
                      },
                    ]}
                  />
                </View>
              </View>

              <View style={styles.projectFooter}>
                <View style={styles.footerItem}>
                  <Ionicons name="list" size={16} color="#6B7280" />
                  <Text style={styles.footerText}>
                    {project.completedTasks}/{project.tasks} Tasks
                  </Text>
                </View>
                <View style={styles.footerItem}>
                  <Ionicons name="people" size={16} color="#6B7280" />
                  <Text style={styles.footerText}>{project.team} Members</Text>
                </View>
              </View>
            </TouchableOpacity>
          ))
        )}
        <View style={styles.bottomSpacer} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    paddingTop: 60,
    backgroundColor: '#fff',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
  },
  filterRow: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 16,
    gap: 8,
    backgroundColor: '#fff',
  },
  filterChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
  },
  filterChipActive: {
    backgroundColor: '#8B5CF6',
  },
  filterText: {
    fontSize: 14,
    color: '#6B7280',
    fontWeight: '500',
  },
  filterTextActive: {
    fontSize: 14,
    color: '#fff',
    fontWeight: '600',
  },
  content: {
    flex: 1,
  },
  center: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
  },
  loadingText: {
    marginTop: 12,
    fontSize: 14,
    color: '#6B7280',
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#6B7280',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 14,
    color: '#9CA3AF',
    textAlign: 'center',
  },
  projectCard: {
    backgroundColor: '#fff',
    marginHorizontal: 20,
    marginTop: 16,
    padding: 20,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 3,
  },
  projectHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  projectIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#F3E8FF',
    justifyContent: 'center',
    alignItems: 'center',
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  projectName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111',
    marginBottom: 8,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  locationText: {
    fontSize: 14,
    color: '#6B7280',
    marginLeft: 4,
  },
  progressSection: {
    marginBottom: 16,
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  progressLabel: {
    fontSize: 14,
    color: '#6B7280',
  },
  progressValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111',
  },
  progressBar: {
    height: 8,
    backgroundColor: '#F3F4F6',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 4,
  },
  projectFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
  },
  footerItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  footerText: {
    fontSize: 14,
    color: '#6B7280',
    marginLeft: 6,
  },
  bottomSpacer: {
    height: 100,
  },
});
