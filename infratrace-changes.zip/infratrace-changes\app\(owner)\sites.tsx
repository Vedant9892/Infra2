import { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Alert,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useUser } from '../../contexts/UserContext';
import { API_BASE_URL } from '../../constants/api';

type Site = {
  id: string;
  name: string;
  location: string;
  code: string;
  workersCount: number;
  status?: string;
  createdAt?: string;
};

export default function Sites() {
  const router = useRouter();
  const { logout } = useUser();
  const [sites, setSites] = useState<Site[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchSites = async () => {
    try {
      const res = await fetch(`${API_BASE_URL}/api/sites`);
      if (!res.ok) throw new Error('Failed to load sites');
      const data = await res.json();
      setSites(data);
    } catch (e) {
      console.error(e);
      Alert.alert('Error', 'Could not load sites. Is the server running?');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchSites();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    fetchSites();
  };

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Logout',
          style: 'destructive',
          onPress: () => {
            logout();
            router.replace('/');
          },
        },
      ]
    );
  };

  const handleSitePress = (site: Site) => {
    router.push({ pathname: '/(owner)/site-detail', params: { code: site.code, id: site.id } });
  };

  const handleAddSite = () => {
    router.push('/(owner)/create-site');
  };

  const handleAddSiteMap = () => {
    router.push('/(owner)/add-site');
  };

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <StatusBar style="dark" />
        <ActivityIndicator size="large" color="#8B5CF6" />
        <Text style={{ marginTop: 12, color: '#6B7280' }}>Loading sites…</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />

      {/* Header */}
      <LinearGradient
        colors={['#8B5CF6', '#7C3AED']}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <View>
            <Text style={styles.headerSubtitle} allowFontScaling={false}>Construction Sites</Text>
            <Text style={styles.headerTitle} allowFontScaling={false}>My Sites</Text>
          </View>
          <View style={styles.headerButtons}>
            <TouchableOpacity
              style={styles.profileButton}
              onPress={() => router.push('/(owner)/profile')}
            >
              <Ionicons name="person-circle-outline" size={28} color="#fff" />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.logoutButton}
              onPress={handleLogout}
            >
              <Ionicons name="log-out-outline" size={26} color="#fff" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.addButton} onPress={handleAddSite}>
              <Ionicons name="add" size={24} color="#8B5CF6" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.addButton} onPress={handleAddSiteMap}>
              <Ionicons name="map" size={24} color="#8B5CF6" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Stats Cards */}
        <View style={styles.statsRow}>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{sites.length}</Text>
            <Text style={styles.statLabel}>Total Sites</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>
              {sites.filter(s => (s.status || 'active') === 'active').length}
            </Text>
            <Text style={styles.statLabel}>Active</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>
              {sites.reduce((sum, s) => sum + s.workersCount, 0)}
            </Text>
            <Text style={styles.statLabel}>Workers</Text>
          </View>
        </View>
      </LinearGradient>

      {/* Sites List */}
      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {sites.length === 0 ? (
          <View style={styles.emptyState}>
            <Ionicons name="business-outline" size={80} color="#D1D5DB" />
            <Text style={styles.emptyTitle}>No Sites Yet</Text>
            <Text style={styles.emptyText}>
              Register your first construction site to get started
            </Text>
            <TouchableOpacity style={styles.emptyButton} onPress={handleAddSite}>
              <Text style={styles.emptyButtonText}>Register Site</Text>
            </TouchableOpacity>
          </View>
        ) : (
          sites.map((site) => (
            <TouchableOpacity
              key={site.id}
              style={styles.siteCard}
              onPress={() => handleSitePress(site)}
              activeOpacity={0.7}
            >
              <View style={styles.siteHeader}>
                <View style={styles.siteIconContainer}>
                  <Ionicons name="construct" size={24} color="#8B5CF6" />
                </View>
                <View style={styles.siteInfo}>
                  <Text style={styles.siteName}>{site.name}</Text>
                  <View style={styles.locationRow}>
                    <Ionicons name="location" size={14} color="#6B7280" />
                    <Text style={styles.siteLocation}>{site.location}</Text>
                  </View>
                  <View style={[styles.codeBadge, { marginTop: 6 }]}>
                    <Ionicons name="key" size={12} color="#8B5CF6" />
                    <Text style={styles.codeText}>{site.code}</Text>
                  </View>
                </View>
              </View>
              <View style={styles.siteStats}>
                <View style={styles.siteStat}>
                  <Ionicons name="people" size={16} color="#6B7280" />
                  <Text style={styles.siteStatText}>{site.workersCount} Workers</Text>
                </View>
              </View>
              <View style={styles.actionRow}>
                <TouchableOpacity
                  style={styles.actionButton}
                  onPress={() => handleSitePress(site)}
                >
                  <Ionicons name="open-outline" size={18} color="#8B5CF6" />
                  <Text style={styles.actionButtonText}>Open dashboard</Text>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          ))
        )}
      </ScrollView>

      {/* Floating Add Button */}
      {sites.length > 0 ? (
        <TouchableOpacity style={styles.fab} onPress={handleAddSite}>
          <LinearGradient
            colors={['#8B5CF6', '#7C3AED']}
            style={styles.fabGradient}
          >
            <Ionicons name="add" size={28} color="#fff" />
          </LinearGradient>
        </TouchableOpacity>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 24,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#E9D5FF',
    marginBottom: 4,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: '#fff',
  },
  addButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  headerButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  profileButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoutButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statsRow: {
    flexDirection: 'row',
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#fff',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#E9D5FF',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 80,
  },
  emptyTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#111',
    marginTop: 24,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 16,
    color: '#6B7280',
    textAlign: 'center',
    marginBottom: 32,
  },
  emptyButton: {
    backgroundColor: '#8B5CF6',
    paddingHorizontal: 32,
    paddingVertical: 16,
    borderRadius: 12,
  },
  emptyButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#fff',
  },
  siteCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 3,
  },
  siteHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  siteIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: '#F3E8FF',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  siteInfo: {
    flex: 1,
  },
  siteName: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111',
    marginBottom: 4,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  siteLocation: {
    fontSize: 14,
    color: '#6B7280',
  },
  codeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#F3E8FF',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  codeText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#8B5CF6',
    letterSpacing: 0.5,
  },
  siteStats: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  siteStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  siteStatText: {
    fontSize: 14,
    color: '#6B7280',
  },
  actionRow: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 8,
    backgroundColor: '#F3E8FF',
    gap: 6,
  },
  actionButtonText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#8B5CF6',
  },
  fab: {
    position: 'absolute',
    right: 20,
    bottom: 20,
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  fabGradient: {
    width: 64,
    height: 64,
    borderRadius: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
