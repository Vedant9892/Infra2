import { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Alert,
  RefreshControl,
  Image,
  ActivityIndicator,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import SiteCodeManagement from '../../mobile-components/SiteCodeManagement';
import { API_BASE_URL } from '../../constants/api';
import { useUser } from '../../contexts/UserContext';

type Worker = {
  id: string;
  userId: string;
  name: string;
  phone: string;
  role: string;
  status: string;
  enrolledAt: string;
  verified: boolean;
};

type PendingMember = {
  id: string;
  userId: string;
  role: string;
  status: string;
  createdAt: string;
};

type SiteData = {
  id: string;
  name: string;
  location: string;
  code: string;
};

export default function SiteDetail() {
  const { id, code } = useLocalSearchParams<{ id: string; code: string }>();
  const router = useRouter();
  const { user } = useUser();
  const [activeTab, setActiveTab] = useState<'overview' | 'workers' | 'pending' | 'settings'>('overview');
  const [site, setSite] = useState<SiteData | null>(null);
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [pendingMembers, setPendingMembers] = useState<PendingMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [approvingId, setApprovingId] = useState<string | null>(null);
  const [rejectingId, setRejectingId] = useState<string | null>(null);

  useEffect(() => {
    fetchSiteData();
  }, [id, code]);

  const fetchSiteData = async () => {
    try {
      setLoading(true);
      let codeParam = (code as string) || '';
      const idParam = (id as string) || '';

      if (!codeParam && idParam) {
        const byIdRes = await fetch(`${API_BASE_URL}/api/sites/id/${encodeURIComponent(idParam)}`);
        if (!byIdRes.ok) {
          Alert.alert('Error', 'Site not found.');
          setLoading(false);
          setRefreshing(false);
          return;
        }
        const siteById = await byIdRes.json();
        codeParam = siteById.code || '';
        if (!codeParam) {
          Alert.alert('Error', 'Site has no code.');
          setLoading(false);
          setRefreshing(false);
          return;
        }
      }

      if (!codeParam) {
        setLoading(false);
        setRefreshing(false);
        return;
      }

      const byCodeRes = await fetch(`${API_BASE_URL}/api/sites/by-code/${encodeURIComponent(codeParam)}`);
      if (!byCodeRes.ok) {
        Alert.alert('Error', 'Site not found for this code.');
        setLoading(false);
        setRefreshing(false);
        return;
      }
      const byCode = await byCodeRes.json();
      setSite(byCode.site);
      const pending = (byCode.memberships || []).filter((m: PendingMember) => m.status === 'pending');
      setPendingMembers(pending);

      if (byCode.site?.id) {
        const workersRes = await fetch(`${API_BASE_URL}/api/sites/${byCode.site.id}/workers`);
        if (workersRes.ok) {
          const w = await workersRes.json();
          setWorkers(w.workers || []);
        }
      }
    } catch (e) {
      console.error(e);
      Alert.alert('Error', 'Could not load site data.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleRefresh = () => {
    setRefreshing(true);
    fetchSiteData();
  };

  const handleApprove = async (membershipId: string) => {
    if (!user) return;
    try {
      setApprovingId(membershipId);
      const res = await fetch(`${API_BASE_URL}/api/sites/memberships/${membershipId}/approve`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ approverId: user.id, approverRole: user.role }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.message || 'Approve failed');
      }
      Alert.alert('Success', 'Worker approved');
      fetchSiteData();
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to approve');
    } finally {
      setApprovingId(null);
    }
  };

  const handleReject = (m: PendingMember) => {
    Alert.alert(
      'Reject enrollment',
      `Reject this ${m.role}? They will need to re-enroll with the site code.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reject',
          style: 'destructive',
          onPress: async () => {
            try {
              setRejectingId(m.id);
              const res = await fetch(`${API_BASE_URL}/api/sites/memberships/${m.id}/reject`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ reason: 'Rejected by supervisor' }),
              });
              if (!res.ok) {
                const err = await res.json().catch(() => ({}));
                throw new Error(err.message || 'Reject failed');
              }
              await fetchSiteData();
              Alert.alert('Done', 'Enrollment rejected.');
            } catch (e: any) {
              Alert.alert('Error', e.message || 'Failed to reject');
            } finally {
              setRejectingId(null);
            }
          },
        },
      ]
    );
  };

  const renderOverview = () => (
    <View style={styles.tabContent}>
      {site && (
        <>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <Ionicons name="people" size={24} color="#8B5CF6" />
              <Text style={styles.statValue}>{verifiedWorkers.length}</Text>
              <Text style={styles.statLabel}>Workers</Text>
            </View>
            <View style={styles.statCard}>
              <Ionicons name="time" size={24} color="#10B981" />
              <Text style={styles.statValue}>{pendingMembers.length}</Text>
              <Text style={styles.statLabel}>Pending</Text>
            </View>
          </View>
          <SiteCodeManagement siteId={site.id} siteName={site.name} siteCode={site.code} />
        </>
      )}

      {/* Quick Actions */}
      <View style={styles.actionsSection}>
        <Text style={styles.sectionTitle}>Quick Actions</Text>
        <View style={styles.actionGrid}>
          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => { setActiveTab('pending'); }}
          >
            <Ionicons name="calendar" size={28} color="#8B5CF6" />
            <Text style={styles.actionText}>Attendance</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => router.push('/(tabs)/home')}
          >
            <Ionicons name="cube" size={28} color="#8B5CF6" />
            <Text style={styles.actionText}>Materials</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => router.push('/(tabs)/home')}
          >
            <Ionicons name="images" size={28} color="#8B5CF6" />
            <Text style={styles.actionText}>Photos</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => router.push('/(tabs)/stats')}
          >
            <Ionicons name="bar-chart" size={28} color="#8B5CF6" />
            <Text style={styles.actionText}>Reports</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  const renderWorkers = () => (
    <View style={styles.tabContent}>
      <Text style={styles.sectionTitle}>All Workers ({verifiedWorkers.length})</Text>
      {verifiedWorkers.length === 0 ? (
        <View style={styles.emptyState}>
          <Ionicons name="people-outline" size={48} color="#D1D5DB" />
          <Text style={styles.emptyTitle}>No workers yet</Text>
          <Text style={styles.emptyText}>Share the site code for workers to join</Text>
        </View>
      ) : (
        verifiedWorkers.map((worker) => (
          <View key={worker.id} style={styles.workerCard}>
            <View style={styles.workerAvatar}>
              <Ionicons name="person" size={32} color="#8B5CF6" />
            </View>
            <View style={styles.workerInfo}>
              <Text style={styles.workerName}>{worker.name}</Text>
              <Text style={styles.workerRole}>{worker.role}</Text>
              {worker.phone ? <Text style={styles.workerPhone}>{worker.phone}</Text> : null}
            </View>
            {worker.verified ? (
              <View style={styles.verifiedBadge}>
                <Ionicons name="checkmark-circle" size={20} color="#10B981" />
                <Text style={styles.verifiedText}>Verified</Text>
              </View>
            ) : (
              <View style={styles.pendingBadge}>
                <Ionicons name="time" size={20} color="#F59E0B" />
                <Text style={styles.pendingText}>Pending</Text>
              </View>
            )}
          </View>
        ))
      )}
    </View>
  );

  const verifiedWorkers = workers.filter((w) => w.verified);

  const renderPendingEnrollments = () => (
    <View style={styles.tabContent}>
      <Text style={styles.sectionTitle}>Pending approvals ({pendingMembers.length})</Text>
      {pendingMembers.length === 0 ? (
        <View style={styles.emptyState}>
          <Ionicons name="checkmark-done" size={64} color="#D1D5DB" />
          <Text style={styles.emptyTitle}>All caught up</Text>
          <Text style={styles.emptyText}>No pending enrollments to review</Text>
        </View>
      ) : (
        pendingMembers.map((m) => {
          const w = workers.find((x) => x.userId === m.userId);
          return (
            <View key={m.id} style={styles.enrollmentCard}>
              <View style={styles.enrollmentHeader}>
                <View>
                  <Text style={styles.enrollmentName}>{w?.name || `User ${m.userId}`}</Text>
                  <Text style={styles.enrollmentRole}>{m.role}</Text>
                  {w?.phone ? <Text style={styles.enrollmentPhone}>{w.phone}</Text> : null}
                  <Text style={styles.enrollmentDate}>
                    Joined {new Date(m.createdAt).toLocaleDateString()}
                  </Text>
                </View>
              </View>
              <View style={styles.enrollmentActions}>
                <TouchableOpacity
                  style={[styles.enrollmentButton, styles.verifyButton]}
                  onPress={() => handleApprove(m.id)}
                  disabled={!!approvingId}
                >
                  {approvingId === m.id ? (
                    <ActivityIndicator size="small" color="#fff" />
                  ) : (
                    <>
                      <Ionicons name="checkmark" size={20} color="#fff" />
                      <Text style={styles.verifyButtonText}>Approve</Text>
                    </>
                  )}
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.enrollmentButton, styles.rejectButton]}
                  onPress={() => handleReject(m)}
                  disabled={!!approvingId || !!rejectingId}
                >
                  {rejectingId === m.id ? (
                    <ActivityIndicator size="small" color="#EF4444" />
                  ) : (
                    <>
                      <Ionicons name="close" size={20} color="#EF4444" />
                      <Text style={styles.rejectButtonText}>Reject</Text>
                    </>
                  )}
                </TouchableOpacity>
              </View>
            </View>
          );
        })
      )}
    </View>
  );

  const renderSettings = () => (
    <View style={styles.tabContent}>
      <Text style={styles.sectionTitle}>Site Settings</Text>
      {site && (
        <>
          <View style={styles.settingCard}>
            <Ionicons name="location" size={24} color="#8B5CF6" />
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>Location</Text>
              <Text style={styles.settingValue}>{site.location}</Text>
            </View>
          </View>
          <View style={styles.settingCard}>
            <Ionicons name="key" size={24} color="#8B5CF6" />
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>Site code</Text>
              <Text style={styles.settingValue}>{site.code}</Text>
            </View>
          </View>
        </>
      )}
    </View>
  );

  if (loading && !site) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <StatusBar style="light" />
        <ActivityIndicator size="large" color="#8B5CF6" />
        <Text style={{ marginTop: 12, color: '#6B7280' }}>Loading site…</Text>
      </View>
    );
  }

  if (!site) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center', padding: 24 }]}>
        <StatusBar style="dark" />
        <Ionicons name="alert-circle" size={48} color="#9CA3AF" />
        <Text style={{ marginTop: 12, fontSize: 16, color: '#374151' }}>Site not found</Text>
        <TouchableOpacity style={{ marginTop: 16, paddingVertical: 10, paddingHorizontal: 20, backgroundColor: '#8B5CF6', borderRadius: 10 }} onPress={() => router.back()}>
          <Text style={{ color: '#fff', fontWeight: '600' }}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <LinearGradient colors={['#8B5CF6', '#7C3AED']} style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="#fff" />
        </TouchableOpacity>
        <View style={styles.headerContent}>
          <Text style={styles.headerTitle}>{site.name}</Text>
          <Text style={styles.headerSubtitle}>{site.location} · {site.code}</Text>
        </View>
      </LinearGradient>

      {/* Tabs */}
      <View style={styles.tabBar}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'overview' && styles.tabActive]}
          onPress={() => setActiveTab('overview')}
        >
          <Ionicons
            name="home"
            size={20}
            color={activeTab === 'overview' ? '#8B5CF6' : '#9CA3AF'}
          />
          <Text style={[styles.tabText, activeTab === 'overview' && styles.tabTextActive]}>
            Overview
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.tab, activeTab === 'workers' && styles.tabActive]}
          onPress={() => setActiveTab('workers')}
        >
          <Ionicons
            name="people"
            size={20}
            color={activeTab === 'workers' ? '#8B5CF6' : '#9CA3AF'}
          />
          <Text style={[styles.tabText, activeTab === 'workers' && styles.tabTextActive]}>
            Workers
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.tab, activeTab === 'pending' && styles.tabActive]}
          onPress={() => setActiveTab('pending')}
        >
          <View>
            <Ionicons
              name="time"
              size={20}
              color={activeTab === 'pending' ? '#8B5CF6' : '#9CA3AF'}
            />
            {pendingMembers.length > 0 ? (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{pendingMembers.length}</Text>
              </View>
            ) : null}
          </View>
          <Text style={[styles.tabText, activeTab === 'pending' && styles.tabTextActive]}>
            Pending
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.tab, activeTab === 'settings' && styles.tabActive]}
          onPress={() => setActiveTab('settings')}
        >
          <Ionicons
            name="settings"
            size={20}
            color={activeTab === 'settings' ? '#8B5CF6' : '#9CA3AF'}
          />
          <Text style={[styles.tabText, activeTab === 'settings' && styles.tabTextActive]}>
            Settings
          </Text>
        </TouchableOpacity>
      </View>

      {/* Tab Content */}
      <ScrollView
        style={styles.scrollView}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}
      >
        {activeTab === 'overview' && renderOverview()}
        {activeTab === 'workers' && renderWorkers()}
        {activeTab === 'pending' && renderPendingEnrollments()}
        {activeTab === 'settings' && renderSettings()}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  backButton: {
    marginBottom: 12,
  },
  headerContent: {
    marginBottom: 8,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#fff',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#E9D5FF',
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  tabActive: {
    borderBottomColor: '#8B5CF6',
  },
  tabText: {
    fontSize: 12,
    color: '#9CA3AF',
    marginTop: 4,
    fontWeight: '600',
  },
  tabTextActive: {
    color: '#8B5CF6',
  },
  badge: {
    position: 'absolute',
    top: -8,
    right: -8,
    backgroundColor: '#EF4444',
    borderRadius: 10,
    minWidth: 20,
    height: 20,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 6,
  },
  badgeText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#fff',
  },
  scrollView: {
    flex: 1,
  },
  tabContent: {
    padding: 20,
  },
  statsGrid: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#111',
    marginTop: 8,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#6B7280',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111',
    marginBottom: 16,
  },
  actionsSection: {
    marginTop: 20,
  },
  actionGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  actionCard: {
    width: '48%',
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  actionText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginTop: 8,
  },
  workerCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  workerAvatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#F3E8FF',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  avatarImage: {
    width: 56,
    height: 56,
    borderRadius: 28,
  },
  workerInfo: {
    flex: 1,
  },
  workerName: {
    fontSize: 16,
    fontWeight: '700',
    color: '#111',
    marginBottom: 2,
  },
  workerRole: {
    fontSize: 13,
    color: '#8B5CF6',
    fontWeight: '600',
    marginBottom: 2,
  },
  workerPhone: {
    fontSize: 13,
    color: '#6B7280',
  },
  verifiedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#D1FAE5',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
  },
  verifiedText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#065F46',
  },
  pendingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#FEF3C7',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
  },
  pendingText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#92400E',
  },
  pendingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  pendingBadgeText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#fff',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#111',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 14,
    color: '#6B7280',
  },
  enrollmentCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  enrollmentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  enrollmentName: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111',
    marginBottom: 4,
  },
  enrollmentRole: {
    fontSize: 14,
    color: '#8B5CF6',
    fontWeight: '600',
    marginBottom: 4,
  },
  enrollmentPhone: {
    fontSize: 13,
    color: '#6B7280',
    marginBottom: 8,
  },
  enrollmentDate: {
    fontSize: 12,
    color: '#9CA3AF',
  },
  enrollmentCodeBadge: {
    backgroundColor: '#F3E8FF',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    height: 32,
  },
  enrollmentCode: {
    fontSize: 16,
    fontWeight: '700',
    color: '#8B5CF6',
    letterSpacing: 2,
  },
  enrollmentActions: {
    flexDirection: 'row',
    gap: 12,
  },
  enrollmentButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 8,
    gap: 6,
  },
  verifyButton: {
    backgroundColor: '#10B981',
  },
  verifyButtonText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#fff',
  },
  rejectButton: {
    backgroundColor: '#fff',
    borderWidth: 2,
    borderColor: '#FEE2E2',
  },
  rejectButtonText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#EF4444',
  },
  settingCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  settingInfo: {
    flex: 1,
    marginLeft: 12,
  },
  settingLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111',
    marginBottom: 2,
  },
  settingValue: {
    fontSize: 13,
    color: '#6B7280',
  },
  dangerButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#FEE2E2',
    paddingVertical: 14,
    borderRadius: 12,
    marginTop: 20,
  },
  dangerButtonText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#EF4444',
  },
});
