import { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  TextInput,
  Modal,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ActivityIndicator,
  Image,
  RefreshControl,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { useLanguage } from '../../contexts/LanguageContext';
import { useUser } from '../../contexts/UserContext';
import { format } from 'date-fns';
import { API_BASE_URL } from '../../constants/api';
import { supabase } from '../../constants/supabase';

type Message = {
  id: string;
  senderId: string;
  senderName?: string;
  senderRole?: string;
  text: string | null;
  photoUrl?: string | null;
  timestamp: Date;
  read: boolean;
};

type Conversation = {
  id: string;
  participantId: string;
  participantName: string;
  participantRole: string;
  lastMessage: string;
  lastMessageTime: Date;
  unreadCount: number;
  messages: Message[];
};

export default function ChatScreen() {
  const { t } = useLanguage();
  const { user } = useUser();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [messageText, setMessageText] = useState('');
  const [showChatModal, setShowChatModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [messagesLoading, setMessagesLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  const fetchConversations = useCallback(async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }
    try {
      const res = await fetch(`${API_BASE_URL}/api/chat/conversations?userId=${encodeURIComponent(user.id)}`);
      if (!res.ok) throw new Error('Failed to load conversations');
      const data = await res.json();
      const list: Conversation[] = (data.conversations || []).map((c: any) => ({
        id: c.id,
        participantId: c.participantId,
        participantName: c.participantName,
        participantRole: c.participantRole,
        lastMessage: c.lastMessage || '',
        lastMessageTime: c.lastMessageTime ? new Date(c.lastMessageTime) : new Date(0),
        unreadCount: c.unreadCount || 0,
        messages: [],
      }));
      setConversations(list);
    } catch (e) {
      console.error(e);
      Alert.alert('Error', 'Could not load conversations. Is the server running?');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id]);

  useEffect(() => {
    setLoading(true);
    fetchConversations();
  }, [fetchConversations]);

  const fetchMessages = useCallback(
    async (otherUserId: string) => {
      if (!user?.id || !otherUserId) return;
      setMessagesLoading(true);
      try {
        const res = await fetch(
          `${API_BASE_URL}/api/chat/messages?userId=${encodeURIComponent(user.id)}&otherUserId=${encodeURIComponent(otherUserId)}`
        );
        if (!res.ok) throw new Error('Failed to load messages');
        const data = await res.json();
        const msgs: Message[] = (data.messages || []).map((m: any) => ({
          id: m.id,
          senderId: m.senderId,
          text: m.text || null,
          photoUrl: m.photoUrl || null,
          timestamp: new Date(m.createdAt),
          read: !!m.read,
        }));
        setSelectedConversation((prev) =>
          prev ? { ...prev, messages: msgs } : null
        );
      } catch (e) {
        console.error(e);
        Alert.alert('Error', 'Could not load messages.');
      } finally {
        setMessagesLoading(false);
      }
    },
    [user?.id]
  );

  const getHierarchyInfo = () => {
    if (!user) return { canChatWith: [], description: '' };

    switch (user.role) {
      case 'labour':
        return {
          canChatWith: ['Supervisor'],
          description: 'Report to your assigned supervisor',
        };
      case 'supervisor':
        return {
          canChatWith: ['Labour (Assigned)', 'Engineer'],
          description: 'Communicate with labour and report to engineer',
        };
      case 'engineer':
        return {
          canChatWith: ['Supervisor', 'Owner'],
          description: 'Coordinate with supervisors and report to owner',
        };
      case 'owner':
        return {
          canChatWith: ['Engineer', 'All Roles'],
          description: 'Access all communications',
        };
      default:
        return { canChatWith: [], description: '' };
    }
  };

  const handleOpenChat = (conversation: Conversation) => {
    setSelectedConversation(conversation);
    setShowChatModal(true);
    fetchMessages(conversation.participantId);
    setConversations((prev) =>
      prev.map((c) => (c.id === conversation.id ? { ...c, unreadCount: 0 } : c))
    );
  };

  const sendMessage = async (text?: string | null, photoUrl?: string | null) => {
    if ((!text || !text.trim()) && !photoUrl) return;
    if (!selectedConversation || !user?.id) return;
    setSending(true);
    try {
      const res = await fetch(`${API_BASE_URL}/api/chat/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderId: user.id,
          receiverId: selectedConversation.participantId,
          ...(text?.trim() && { text: text.trim() }),
          ...(photoUrl && { photoUrl }),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Send failed');
      const m: Message = {
        id: data.id,
        senderId: user.id,
        text: data.text || null,
        photoUrl: data.photoUrl || null,
        timestamp: new Date(data.createdAt),
        read: !!data.read,
      };
      setSelectedConversation((prev) =>
        prev
          ? {
              ...prev,
              messages: [...prev.messages, m],
              lastMessage: photoUrl ? '[Photo]' : (text?.trim() || ''),
              lastMessageTime: new Date(),
            }
          : null
      );
      setConversations((prev) =>
        prev.map((c) =>
          c.id === selectedConversation.id
            ? {
                ...c,
                lastMessage: photoUrl ? '[Photo]' : (text?.trim() || ''),
                lastMessageTime: new Date(),
              }
            : c
        )
      );
      setMessageText('');
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Could not send message.');
    } finally {
      setSending(false);
    }
  };

  const handleSendMessage = () => {
    sendMessage(messageText, null);
  };

  const handleAttachPhoto = async () => {
    if (!user?.id || !selectedConversation) return;
    try {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Denied', 'We need gallery access to attach photos.');
        return;
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
        base64: true,
      });
      if (result.canceled || !result.assets[0]?.base64) return;
      setUploadingPhoto(true);
      const base64 = result.assets[0].base64;
      const ext = result.assets[0].uri?.split('.').pop() || 'jpg';
      const fileName = `chat/${user.id}-${Date.now()}.${ext}`;
      const byteChars = atob(base64);
      const byteNumbers = new Array(byteChars.length);
      for (let i = 0; i < byteChars.length; i++) byteNumbers[i] = byteChars.charCodeAt(i);
      const byteArray = new Uint8Array(byteNumbers);
      const { error } = await supabase.storage
        .from('profile-photos')
        .upload(fileName, byteArray, { contentType: 'image/jpeg', upsert: true });
      if (error) throw new Error(error.message);
      const { data: urlData } = supabase.storage.from('profile-photos').getPublicUrl(fileName);
      await sendMessage(null, urlData.publicUrl);
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Could not attach photo.');
    } finally {
      setUploadingPhoto(false);
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'labour':
        return '#F59E0B';
      case 'supervisor':
        return '#10B981';
      case 'engineer':
        return '#3B82F6';
      case 'owner':
        return '#8B5CF6';
      default:
        return '#6B7280';
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'labour':
        return 'construct';
      case 'supervisor':
        return 'people';
      case 'engineer':
        return 'build';
      case 'owner':
        return 'business';
      default:
        return 'person';
    }
  };

  const hierarchyInfo = getHierarchyInfo();

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Messages</Text>
        <View style={styles.headerRight}>
          <TouchableOpacity style={styles.iconButton}>
            <Ionicons name="search" size={22} color="#111" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Hierarchy Info Card */}
      <View style={styles.hierarchyCard}>
        <View style={styles.hierarchyHeader}>
          <Ionicons name="git-network" size={20} color="#8B5CF6" />
          <Text style={styles.hierarchyTitle}>Communication Hierarchy</Text>
        </View>
        <Text style={styles.hierarchyDescription}>{hierarchyInfo.description}</Text>
        <View style={styles.hierarchyBadges}>
          {hierarchyInfo.canChatWith.map((role, index) => (
            <View key={index} style={styles.hierarchyBadge}>
              <Text style={styles.hierarchyBadgeText}>{role}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Conversations List */}
      <ScrollView
        style={styles.conversationsList}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchConversations(); }} />
        }
      >
        {loading ? (
          <View style={styles.emptyState}>
            <ActivityIndicator size="large" color="#8B5CF6" />
            <Text style={styles.emptyStateText}>Loading…</Text>
          </View>
        ) : !user?.id ? (
          <View style={styles.emptyState}>
            <Ionicons name="person-outline" size={64} color="#D1D5DB" />
            <Text style={styles.emptyStateTitle}>Sign in</Text>
            <Text style={styles.emptyStateText}>Sign in to see your conversations</Text>
          </View>
        ) : conversations.length === 0 ? (
          <View style={styles.emptyState}>
            <Ionicons name="chatbubbles-outline" size={64} color="#D1D5DB" />
            <Text style={styles.emptyStateTitle}>No Conversations</Text>
            <Text style={styles.emptyStateText}>
              Your hierarchical contacts will appear here. Join a site if you have none.
            </Text>
          </View>
        ) : (
          conversations.map((conversation) => (
            <TouchableOpacity
              key={conversation.id}
              style={styles.conversationCard}
              onPress={() => handleOpenChat(conversation)}
            >
              <View
                style={[
                  styles.conversationAvatar,
                  { backgroundColor: getRoleColor(conversation.participantRole) + '20' },
                ]}
              >
                <Ionicons
                  name={getRoleIcon(conversation.participantRole) as any}
                  size={24}
                  color={getRoleColor(conversation.participantRole)}
                />
              </View>

              <View style={styles.conversationContent}>
                <View style={styles.conversationHeader}>
                  <Text style={styles.conversationName}>{conversation.participantName}</Text>
                  <Text style={styles.conversationTime}>
                    {conversation.lastMessage
                      ? format(conversation.lastMessageTime, 'HH:mm')
                      : '—'}
                  </Text>
                </View>
                <View style={styles.conversationFooter}>
                  <View style={styles.conversationRoleBadge}>
                    <Text style={styles.conversationRoleText}>
                      {conversation.participantRole.toUpperCase()}
                    </Text>
                  </View>
                  <Text style={styles.conversationLastMessage} numberOfLines={1}>
                    {conversation.lastMessage}
                  </Text>
                </View>
              </View>

              {conversation.unreadCount > 0 ? (
                <View style={styles.unreadBadge}>
                  <Text style={styles.unreadBadgeText}>{conversation.unreadCount}</Text>
                </View>
              ) : null}
            </TouchableOpacity>
          ))
        )}
      </ScrollView>

      {/* Chat Modal */}
      <Modal
        visible={showChatModal}
        animationType="slide"
        onRequestClose={() => setShowChatModal(false)}
      >
        {selectedConversation && (
          <KeyboardAvoidingView
            style={styles.chatContainer}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            keyboardVerticalOffset={0}
          >
            <StatusBar style="dark" />
            
            {/* Chat Header */}
            <View style={styles.chatHeader}>
              <TouchableOpacity
                style={styles.backButton}
                onPress={() => setShowChatModal(false)}
              >
                <Ionicons name="arrow-back" size={24} color="#111" />
              </TouchableOpacity>

              <View style={styles.chatHeaderContent}>
                <View
                  style={[
                    styles.chatAvatar,
                    { backgroundColor: getRoleColor(selectedConversation.participantRole) + '20' },
                  ]}
                >
                  <Ionicons
                    name={getRoleIcon(selectedConversation.participantRole) as any}
                    size={20}
                    color={getRoleColor(selectedConversation.participantRole)}
                  />
                </View>
                <View>
                  <Text style={styles.chatHeaderName}>{selectedConversation.participantName}</Text>
                  <Text style={styles.chatHeaderRole}>
                    {selectedConversation.participantRole.toUpperCase()}
                  </Text>
                </View>
              </View>

              <TouchableOpacity style={styles.iconButton}>
                <Ionicons name="ellipsis-vertical" size={20} color="#111" />
              </TouchableOpacity>
            </View>

            {/* Messages Area */}
            <ScrollView style={styles.messagesArea} contentContainerStyle={styles.messagesContent}>
              {messagesLoading ? (
                <View style={styles.noMessagesState}>
                  <ActivityIndicator size="large" color="#8B5CF6" />
                  <Text style={styles.noMessagesSubtext}>Loading messages…</Text>
                </View>
              ) : selectedConversation.messages.length === 0 ? (
                <View style={styles.noMessagesState}>
                  <Ionicons name="mail-open-outline" size={48} color="#D1D5DB" />
                  <Text style={styles.noMessagesText}>No messages yet</Text>
                  <Text style={styles.noMessagesSubtext}>Start the conversation</Text>
                </View>
              ) : (
                selectedConversation.messages.map((message) => {
                  const isSent = message.senderId === user?.id;
                  return (
                    <View
                      key={message.id}
                      style={[
                        styles.messageBubble,
                        isSent ? styles.messageBubbleSent : styles.messageBubbleReceived,
                      ]}
                    >
                      {message.photoUrl ? (
                        <Image source={{ uri: message.photoUrl }} style={styles.messagePhoto} resizeMode="cover" />
                      ) : null}
                      {message.text ? (
                        <Text
                          style={[
                            styles.messageText,
                            isSent ? styles.messageTextSent : styles.messageTextReceived,
                          ]}
                        >
                          {message.text}
                        </Text>
                      ) : null}
                      <Text
                        style={[
                          styles.messageTime,
                          isSent ? styles.messageTimeSent : styles.messageTimeReceived,
                        ]}
                      >
                        {format(message.timestamp, 'HH:mm')}
                      </Text>
                    </View>
                  );
                })
              )}
            </ScrollView>

            {/* Message Input */}
            <View style={styles.inputContainer}>
              <TouchableOpacity
                style={styles.attachButton}
                onPress={handleAttachPhoto}
                disabled={uploadingPhoto || sending}
              >
                {uploadingPhoto ? (
                  <ActivityIndicator size="small" color="#8B5CF6" />
                ) : (
                  <Ionicons name="image" size={26} color="#8B5CF6" />
                )}
              </TouchableOpacity>
              <TextInput
                style={styles.messageInput}
                placeholder="Type a message..."
                placeholderTextColor="#9CA3AF"
                value={messageText}
                onChangeText={setMessageText}
                multiline
                editable={!sending && !uploadingPhoto}
              />
              <TouchableOpacity
                style={[
                  styles.sendButton,
                  !messageText.trim() && styles.sendButtonDisabled,
                ]}
                onPress={handleSendMessage}
                disabled={!messageText.trim() || sending}
              >
                {sending && messageText.trim() ? (
                  <ActivityIndicator size="small" color="#fff" />
                ) : (
                  <Ionicons
                    name="send"
                    size={20}
                    color={messageText.trim() ? '#fff' : '#D1D5DB'}
                  />
                )}
              </TouchableOpacity>
            </View>
          </KeyboardAvoidingView>
        )}
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 16,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#111',
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
  },
  hierarchyCard: {
    backgroundColor: '#fff',
    margin: 20,
    padding: 16,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  hierarchyHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  hierarchyTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: '#111',
    marginLeft: 8,
  },
  hierarchyDescription: {
    fontSize: 13,
    color: '#6B7280',
    marginBottom: 12,
  },
  hierarchyBadges: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  hierarchyBadge: {
    backgroundColor: '#F3E8FF',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  hierarchyBadgeText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#8B5CF6',
  },
  conversationsList: {
    flex: 1,
  },
  conversationCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 16,
    marginHorizontal: 20,
    marginBottom: 12,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  conversationAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  conversationContent: {
    flex: 1,
  },
  conversationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  conversationName: {
    fontSize: 16,
    fontWeight: '700',
    color: '#111',
  },
  conversationTime: {
    fontSize: 12,
    color: '#9CA3AF',
  },
  conversationFooter: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  conversationRoleBadge: {
    backgroundColor: '#F3F4F6',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
    marginRight: 8,
  },
  conversationRoleText: {
    fontSize: 9,
    fontWeight: '700',
    color: '#6B7280',
  },
  conversationLastMessage: {
    flex: 1,
    fontSize: 13,
    color: '#6B7280',
  },
  unreadBadge: {
    backgroundColor: '#8B5CF6',
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 8,
  },
  unreadBadgeText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#fff',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
  },
  emptyStateTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#6B7280',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyStateText: {
    fontSize: 14,
    color: '#9CA3AF',
    textAlign: 'center',
  },
  chatContainer: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  chatHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 60,
    paddingBottom: 16,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
  },
  chatHeaderContent: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  chatAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  chatHeaderName: {
    fontSize: 16,
    fontWeight: '700',
    color: '#111',
  },
  chatHeaderRole: {
    fontSize: 11,
    fontWeight: '600',
    color: '#6B7280',
  },
  messagesArea: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  messagesContent: {
    padding: 16,
  },
  noMessagesState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 100,
  },
  noMessagesText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#6B7280',
    marginTop: 12,
  },
  noMessagesSubtext: {
    fontSize: 13,
    color: '#9CA3AF',
    marginTop: 4,
  },
  messageBubble: {
    maxWidth: '75%',
    padding: 12,
    borderRadius: 16,
    marginBottom: 12,
  },
  messageBubbleSent: {
    backgroundColor: '#8B5CF6',
    alignSelf: 'flex-end',
    borderBottomRightRadius: 4,
  },
  messageBubbleReceived: {
    backgroundColor: '#fff',
    alignSelf: 'flex-start',
    borderBottomLeftRadius: 4,
  },
  messagePhoto: {
    width: 200,
    height: 150,
    borderRadius: 12,
    marginBottom: 6,
  },
  messageText: {
    fontSize: 15,
    lineHeight: 20,
    marginBottom: 4,
  },
  messageTextSent: {
    color: '#fff',
  },
  messageTextReceived: {
    color: '#111',
  },
  messageTime: {
    fontSize: 11,
  },
  messageTimeSent: {
    color: 'rgba(255, 255, 255, 0.7)',
  },
  messageTimeReceived: {
    color: '#9CA3AF',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
  },
  attachButton: {
    marginRight: 8,
    marginBottom: 8,
  },
  messageInput: {
    flex: 1,
    backgroundColor: '#F3F4F6',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 10,
    fontSize: 15,
    color: '#111',
    maxHeight: 100,
  },
  sendButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#8B5CF6',
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 8,
  },
  sendButtonDisabled: {
    backgroundColor: '#F3F4F6',
  },
});
